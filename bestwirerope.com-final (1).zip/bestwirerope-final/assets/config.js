window.BWR_CONFIG = {
  supabaseUrl: 'PASTE_SUPABASE_PROJECT_URL_HERE',
  supabasePublishableKey: 'PASTE_SUPABASE_PUBLISHABLE_KEY_HERE',
  storageBucket: 'bestwirerope-images'
};
